### avsubtitleswriter for OSX ###

===========================================================================
DESCRIPTION:

A command line tool that demonstrates writing subtitles to a movie. This is accomplished with AVAssetReader, AVAssetWriter, and the SubtitlesTextReader. The tool takes steps to preserve much of the source movies tracks and metadata in the new movie it writes out.

===========================================================================
BUILD REQUIREMENTS:

Xcode 5.0 or later, Mac OS X v10.9 or later

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X v10.9 or later

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.0
- First version.

===========================================================================
Copyright (C) 2013 Apple Inc. All rights reserved.
