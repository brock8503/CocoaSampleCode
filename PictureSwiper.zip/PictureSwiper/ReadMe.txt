### PictureSwiper ###

================================================================================
DESCRIPTION:

Demonstrates how to use NSPageController class for swipe navigation and animations between views or view content, in a user interface with pages or history.

Requires a Magic Mouse or Trackpad.

================================================================================
BUILD REQUIREMENTS:

OS X Mountain Lion

================================================================================
RUNTIME REQUIREMENTS:

OS X Mountain Lion

================================================================================
CHANGES FROM PREVIOUS VERSIONS:

1.1 - Updated to use NSPageController
1.0 - First Version

================================================================================
Copyright (C) 2011-2012 Apple Inc. All rights reserved.
