### InfoBarStackView ###

===========================================================================
DESCRIPTION:

Demonstrates how to use NSStackView, to show how to stack arbitrary views together.
Each view in the stack can be hidden or shown independently.

===========================================================================
BUILD REQUIREMENTS:

Xcode 5.0 or later, OS X 10.9 or later

===========================================================================
RUNTIME REQUIREMENTS:

OS X 10.9 or later

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

1.0 - First version.

===========================================================================
Copyright (C) 2013 Apple Inc. All rights reserved.
